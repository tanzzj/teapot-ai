import{c as e,s as r}from"./flowDiagram-UKHOOZJN-3rkB4oXR.js";import{_ as a}from"./index-DKu43qR2.js";import"./chunk-5VM5RSS4-BGdIu6KT.js";import"./chunk-XXDRQBXY-CPyJ7a0u.js";import"./chunk-KBJHAD2P-BE1Ir9o_.js";import"./chunk-2GRJ4B5K-BppFQeQU.js";import"./channel-BTZWuB7i.js";var o=a(t=>`${r(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=e({defaultLayout:"swimlane",styles:s});export{f as diagram};
